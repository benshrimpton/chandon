<?php
$path = defined('EE_APPPATH') ? EE_APPPATH : APPPATH;
require "$path/modules/moblog/language/english/moblog_lang.php";