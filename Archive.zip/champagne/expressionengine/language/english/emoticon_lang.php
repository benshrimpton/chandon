<?php

$lang = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

'emoticon_module_name' =>
'Emoticon',

'emoticon_module_description' =>
'Emoticon (smiley) module',


//----------------------------------------
// Emoticon language lines
//----------------------------------------

'emoticon_heading' =>
'Emoticons',

'emoticon_glyph' =>
'Glyph',

'emoticon_image' =>
'Image',

'emoticon_width' =>
'Width',

'emoticon_height' =>
'Height',

'emoticon_alt' =>
'Alt tag',



''=>''
);

/* End of file emoticon_lang.php */
/* Location: ./system/expressionengine/language/english/emoticon_lang.php */